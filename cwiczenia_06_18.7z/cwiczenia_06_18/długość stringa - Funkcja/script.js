'use strict';

function sprawdzDlugosc(strink){
strink = String(strink);

if (strink === undefined || strink === null || strink === "") alert('błąd');

else if (strink.lenght > 5) alert('Długi string');
else alert('Krótki string');

}
let strink = prompt("Podaj string");
sprawdzDlugosc(strink);
console.log(strink);