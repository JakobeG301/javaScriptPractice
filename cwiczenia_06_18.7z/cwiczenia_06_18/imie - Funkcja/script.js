'use strict';

function powitanie(im, wi)
{
    wi = Number(wi);
    console.log(`Cześć, nazywam się ${im} i mam ${wi} lat`);
}
let wiek = prompt("Jaki wiek?"); 
let imie = prompt("Jakie imie?");

powitanie(imie, wiek);