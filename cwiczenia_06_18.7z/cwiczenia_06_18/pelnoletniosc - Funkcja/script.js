'use strict';

function czyPełnoletni(wiek)
{
if (wiek === undefined || wiek === null || wiek === "") alert ('Wiek nieznany');

wiek = Number(wiek);

if(isNaN(wiek)) alert ("Podana wartość nie jest liczbą");

    else if(wiek >= 18) alert ('Jesteś pełnoletni');

    else if(wiek < 18 && wiek > 0){alert ('Jesteś niepełnoletni');}
}

let wiek = prompt("Podaj wiek:");

wiek = wiek.trim();

czyPełnoletni(wiek);