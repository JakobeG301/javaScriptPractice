'use strict';

const obliczWiek = dataUrodzin => 2024 - dataUrodzin;

const wiekAlbert = obliczWiek(2001);

console.log(wiekAlbert);


const obliczEmeryt = (dataUrodzin, imie) => {

    dataUrodzin = Number(dataUrodzin);
    const rokKonca = dataUrodzin + 65;

    console.log(`${imie} przejdzie na emeryture w ${rokKonca} roku.`);
}
const emerytJakub = obliczEmeryt(2001, "Jakub");
console.log(emerytJakub);